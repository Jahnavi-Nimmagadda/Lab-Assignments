package Lab5;
import java.util.Scanner;

class NameException extends Throwable
{
	public NameException(String errorMsg)
	{
		super(errorMsg);
	}
}
public class ValidateName {
	static void validation(String Fn,String Ln) throws NameException
	{
		if((Fn.equals(""))&&(Ln.equals("")))
			throw new NameException("Validate full name of employee");
		else
			System.out.println("Name of the employee is valid");
	}

	public static void main(String[] args) throws NameException
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Employee First Name:");
		String Fn=sc.next();
		System.out.println("Enter Employee Last Name:");
		String Ln=sc.next();

	ValidateName.validation(Fn,Ln);
	System.out.println("rest of the code....");

	}

}

