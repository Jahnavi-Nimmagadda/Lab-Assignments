package Lab5;
import java.util.Scanner;

public class Fibonacci {
	static int fibonacci(int d) {
		if (d <= 1){
			return d;
		}
		return fibonacci(d - 1) + fibonacci(d - 2);
	}

	@SuppressWarnings("static-access")
	public static void main(String[] args) {
		@SuppressWarnings("resource")
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the position number in the sequnce");
		int n = sc.nextInt();
		int d=n;
		Fibonacci p = new Fibonacci();
		System.out.println("using recursive "+d+"th number in the fibonacci sequence is "+p.fibonacci(d));
		int a = 0, b = 1, c = 0;
		while (n > 1) {
			c = a + b;
			a = b;
			b = c;
			n--;
		}
		System.out.println("using non recursive "+d+"th number in the fibonacci sequence is "+c);
		
	}

}
