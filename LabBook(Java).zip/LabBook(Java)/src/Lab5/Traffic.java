package Lab5;

import java.util.Scanner;

public class Traffic {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the string:");
		String s=sc.next();
		switch(s)
		{
		case("red"):
		System.out.println("STOP");
		break;
		case("yellow"):
			System.out.println("READY");
		break;
		case("green"):
			System.out.println("GO");
		break;
		default:
			System.out.println("Invalid Input");
		}
		


	}

}
