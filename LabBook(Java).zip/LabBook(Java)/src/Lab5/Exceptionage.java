package Lab5;

import java.util.Scanner;

class InvalidAgexception extends Throwable{
	public InvalidAgexception(String errorMsg)
	{
		super(errorMsg);
	}
}

public class Exceptionage {
	static void validation(int age1) throws InvalidAgexception
	{
		if(age1<15)
			throw new InvalidAgexception("Your age is less than 15");
		else
			System.out.println("Your age is more than 15");
	}

	public static void main(String[] args) throws InvalidAgexception
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the age:");
		int n=sc.nextInt();
	Exceptionage.validation(n);
	System.out.println("rest of the code....");

	}

}
