package Lab1;

import java.util.Scanner;

public class CheckPower {
	boolean checkNumber(int n)
	{
		boolean b=true;
		while(n>1)
		{
			if(n%2!=0)
			{
			b=false;
		}
		n=n/2;
	}
	return b;
}

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		CheckPower d=new CheckPower();
		boolean b=d.checkNumber(n);
		System.out.println(b);

	}

}
