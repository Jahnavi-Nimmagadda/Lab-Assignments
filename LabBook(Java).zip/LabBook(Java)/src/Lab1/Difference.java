package Lab1;
import java.util.Scanner;
public class Difference {
	void calculateDifference(int n)
	{
		int difference=0,s,q;	
    		q=(n*(n+1)*((2*n)+1))/6;
			s=((n*(n+1))/2)^2;
			difference=q-s;
		System.out.println(difference);
	
	}

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the range of n:");
		int n=sc.nextInt();
		Difference d=new Difference();
		d.calculateDifference(n);	
	}
}
