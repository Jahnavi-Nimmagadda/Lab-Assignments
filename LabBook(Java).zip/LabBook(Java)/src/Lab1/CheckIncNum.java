package Lab1;

import java.util.Scanner;

public class CheckIncNum{
	boolean checkNumber(int n)
	{
		int l=9,f;
	boolean b=true;
	while(n>0)
	{
		f=n%10;
		n=n/10;
		if(f>l) 
		{
			b=false;
			break;
		}
		l=f;
	}
	return b;
	}

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		CheckIncNum d=new CheckIncNum();
		boolean b=d.checkNumber(n);
		System.out.println(b);
	
	}

}
