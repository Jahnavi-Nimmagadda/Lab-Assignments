package Lab4;

import java.util.Scanner;

public class Digitscube {


	public static void main(String[] args)
	{
		int r,s=0;
		Scanner sc=new Scanner(System.in);
		System.out.println("enter n");
		int n=sc.nextInt();
		while(n>0)
		{
			r=n%10;
			n=n/10;
			s=s+(r*r*r);
			
		}
	System.out.println(s);
	}

}
