package Lab6;


import java.util.Scanner;
 class MirrorEx3{
public String getImage(String s)
{
StringBuffer sb=new StringBuffer(s);
sb.reverse();
String t=sb.toString();
	return t;

} 
	 
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		 
		  System.out.println("enter string");
		  MirrorEx3 d= new MirrorEx3();
		 
	String s=sc.next();
	System.out.println("Mirror image of the given string is:");
		System.out.println(s+"|"+d.getImage(s));  
		  
	}
 }