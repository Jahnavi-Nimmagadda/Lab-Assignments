package Lab6;


import java.util.Scanner;

public class Lab6Ex5 {
	int modifyNumber(int number1) {
		String s = Integer.toString(number1);
		int j = 0;
		StringBuffer sb = new StringBuffer();
		for (int i = 0; i < s.length() - 1; i++) {
			j = Math.abs(s.charAt(i) - s.charAt(i + 1));

			sb.append(j);

		}
		sb.append(s.charAt((int) s.length() - 1));
		String s2 = sb.toString();
		int b = Integer.parseInt(s2);
		number1 = b;

		return number1;
	}

	public static void main(String[] args) {
		System.out.println("Enter the number");
		@SuppressWarnings("resource")
		Scanner sc = new Scanner(System.in);
		int a = sc.nextInt();
		Lab6Ex5 p = new Lab6Ex5();
		System.out.println(p.modifyNumber(a));
	}

}
