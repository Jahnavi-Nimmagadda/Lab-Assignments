package Lab6;
import java.io.*; 
public class CountDisplayEx6 {
public static void main(String[] args) throws IOException{ 
				File f= new File("cap1.txt"); 
				FileInputStream fileStream = new FileInputStream(f); 
				InputStreamReader input = new InputStreamReader(fileStream); 
				BufferedReader reader = new BufferedReader(input); 
				String line; 
				int countWord = 0;// Initializing counters  
				int sentenceCount = 0; 
				int characterCount = 0; 
while((line = reader.readLine()) != null)// Reading line by line from the file until a null is returned 
				{ 
					if(!(line.equals(""))) 
					{ 	
						characterCount += line.length(); 
			String[] wordList = line.split("\\s+");// \\s+ is the space delimiter in java 
						countWord += wordList.length;  
String[] sentenceList = line.split("[!?.:]+"); // [!?.:]+ is the sentence delimiter in java
						sentenceCount += sentenceList.length; 
					} } 
				System.out.println("Total word count = " + countWord); 
				System.out.println("Total number of sentences = " + sentenceCount); 
				System.out.println("Total number of characters = " + characterCount); 
		} }