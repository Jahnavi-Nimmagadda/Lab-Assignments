package Lab6;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Month;
import java.time.Period;
import java.util.Date;
import java.util.Scanner;
public class DurationinYearsEx9 {
	public static void main(String[] args) {
		LocalDate  pdate=LocalDate.now();
	System.out.println("Today's date is:"+pdate);
	SimpleDateFormat sdf1=new SimpleDateFormat("dd-M-yyyy");
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter year,month,date: ");
	int year=sc.nextInt();
	int month=sc.nextInt();
	int date=sc.nextInt();
	Period diff = Period.between(LocalDate.of(year,month,date),pdate);
	System.out.printf("Difference is %d years, %d months and %d days\n\n",
	                Math.abs(diff.getYears()),Math.abs(diff.getMonths()),Math.abs(diff.getDays()));
	}
	}
