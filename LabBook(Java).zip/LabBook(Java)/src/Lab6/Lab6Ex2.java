package Lab6;

import java.io.IOException;
import java.io.*;

public class Lab6Ex2 {

	public static void main(String[] args) throws IOException {
       FileReader f1=new FileReader("cap1.txt");
       LineNumberReader l1=new LineNumberReader(f1);
       String line=null;
       while((line=l1.readLine())!=null)
       {
    	   System.out.println(l1.getLineNumber()+" "+line);
       }
	}

}
