package Lab6;

import java.io.File;
import java.util.Scanner;
public class CheckFileReadabilityEx7 {
public static void main(String[] args) {
System.out.println("enter the file name in the format filename.txt:");
Scanner input=new Scanner(System.in);
String s=input.nextLine();
File f1=new File(s);
System.out.println("FileName:"+f1.getName());
System.out.println("This file is:"+(f1.exists()?"Exists":"Does not exists"));
System.out.println("Is file:"+f1.isFile());
System.out.println("Is Directory:"+f1.isDirectory());
System.out.println("Is Readable:"+f1.canRead());
System.out.println("Is Writable:"+f1.canWrite());
System.out.println("File Size:"+f1.length()+"bytes");
}}