
package Lab6;
import java.util.Scanner;
public class JobseekerEx10 {
	public static boolean check(String str){
String seekername=str.concat("_job");
System.out.println(seekername);
		if(str.length()<8)
			return false;
		return true;
	}
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the string");
		String name=sc.next();
				System.out.println(check(name));

	}

}
