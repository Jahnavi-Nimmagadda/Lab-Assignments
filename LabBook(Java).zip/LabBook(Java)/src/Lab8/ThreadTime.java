package Lab8;
import java.util.*;
public class ThreadTime extends TimerTask  implements Runnable
{
	public void run()
	{
		System.out.println("timer update.."+new Date());
	}
	public static void main(String[] args) throws InterruptedException
	{
		TimerTask timertask=new ThreadTime();
		Timer timer=new Timer(true);
		timer.scheduleAtFixedRate(timertask,0,10*1000);
		System.out.println("timer update is started");
		Thread.sleep(100000);
		timer.cancel();
		System.out.println("timer is stopped");
	}
}

