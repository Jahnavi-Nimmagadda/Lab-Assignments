package Lab8;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class FileProgram {

	public static void main(String[] args) throws IOException,InterruptedException
	{
		FileInputStream f1=null;
		f1=new FileInputStream("d:\\Capp.txt");
		FileOutputStream f2=null;
		f2=new FileOutputStream("d:\\Cap.txt");
		CopyDataThread o=new CopyDataThread(f1,f2);
	}
}
