package Lab9;


	import java.io.FileInputStream;
	import java.io.FileOutputStream;
	import java.io.IOException;
	import java.util.concurrent.ExecutorService;
	import java.util.concurrent.Executors;

import Lab8.CopyDataThread;

	public class FileProg{
		//static FileInputStream f1=null;
		public static void main(String[] args) throws IOException, InterruptedException {
			// TODO Auto-generated method stub
			FileInputStream f1=null;
			FileOutputStream f2=null;
			try {
				f1=new FileInputStream("d:\\Cap.txt");
				f2=new FileOutputStream("d:\\gemini.txt");
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			CopyDataThread cdt=new CopyDataThread(f1,f2);
			ExecutorService ex=Executors.newFixedThreadPool(1);
			ex.execute(cdt);
		}

	}


