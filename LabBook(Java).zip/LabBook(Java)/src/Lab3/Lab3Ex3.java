package Lab3;

import java.util.Scanner;
public class Lab3Ex3 {
	public int[] getSorted(int a[])
	{
		int i,temp;
		String sbu=new String();
		for(i=0;i<a.length;i++)
		{
			sbu=Integer.toString(a[i]);
			StringBuffer sbu2=new StringBuffer(sbu);
			sbu2=sbu2.reverse();
			String sbu1=sbu2.toString();
			a[i]=Integer.parseInt(sbu1);
		}
		for(i=0;i<a.length;i++){
			for(int j=i+1;j<a.length;j++)
			{
				if(a[i]>a[j])
				{
					temp=a[i];
					a[i]=a[j];
					a[j]=temp;
				}
			}
		}
		return a;
	}

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		int a[]=new int[n];
		int b[]=new int[n];
		Lab3Ex3 d=new Lab3Ex3();
		for(int i=0;i<n;i++){
			a[i]=sc.nextInt();
		}
		b=d.getSorted(a);
		for(int i:b)
			System.out.println(i);
	}

}
