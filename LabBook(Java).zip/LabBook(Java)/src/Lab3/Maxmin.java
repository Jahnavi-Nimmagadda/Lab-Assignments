package Lab3;

public class Maxmin {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
