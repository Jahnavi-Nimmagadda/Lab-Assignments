package Lab7;
import java.util.*;
public class Lab7Ex8 {
int[] modifyArray(int[] a)
{
	List<Integer> k=new ArrayList<Integer>();
	for(int i=0;i<a.length;i++)
	{
		k.add((Integer)a[i]);
	}
	Set<Integer> s=new HashSet<Integer>(k);
	List<Integer> list=new ArrayList<Integer>(s);
	Collections.sort(list);
	
	int b[]=new int[list.size()];
	int j=0;
	for(int i=list.size()-1;i>=0;i--)
	{
		b[j]=(Integer)list.get(i);
		j++;
	}
	return b;
}
	public static void main(String[] args) {
		Lab7Ex8 l=new Lab7Ex8();
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the length of string");
		int n=sc.nextInt();
		int a[]=new int[n];
		System.out.println("enter the elements of the array:");
		int arr[]=new int[a.length];		
		for(int i=0;i<a.length;i++)
		{
			a[i]=sc.nextInt();

		}
		arr=l.modifyArray(a);
		System.out.println("sorted array list");
		System.out.println(Arrays.toString(arr));
		}
	}




