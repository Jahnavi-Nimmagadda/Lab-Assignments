package Lab7;

import java.util.*;
public class Lab7Ex7 {
int[] getSorted(int a[])
{
	
	int b[]=new int[a.length];
	for(int i=0;i<a.length;i++)
	{
		String a1=Integer.toString(a[i]);
		StringBuffer ab=new StringBuffer(a1);
		b[i]=Integer.parseInt(ab.reverse().toString());
		
	}
	List<Integer> k=new ArrayList<Integer>();
	for(int i=0;i<a.length;i++)
	{
		k.add(b[i]);
	}
	Collections.sort(k);
int arr[]=new int[a.length];
for(int i=0;i<a.length;i++)
{
	arr[i]=k.get(i);
}
return arr;
}
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		Lab7Ex7 l=new Lab7Ex7();
		System.out.println("enter the length of string");
		int n=sc.nextInt();
		System.out.println("enter the elements of the array:");
		int a[]=new int[n];
		
	
		for(int i=0;i<a.length;i++)
		{
			a[i]=sc.nextInt();

		}
	int arr[]=l.getSorted(a);
	System.out.println("sorted array elements are");
		System.out.println(Arrays.toString(arr));
		}
	}