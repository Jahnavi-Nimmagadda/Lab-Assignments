package Lab7;

import java.util.*;

public class Lab7Ex2 {
   public Map<Character,Integer> countCharacter(char[] a)
   {
	   Map<Character,Integer> m=new HashMap<Character,Integer>();
	   int arr[]=new int[256];
	   for(int i=0;i<a.length;i++)
	   {
		   arr[a[i]]++;
	   }
	   char array[]=new char[a.length];
	   for(int i=0;i<a.length;i++)
	   {
		   array[i]=a[i];
		   int count=0;
		   for(int j=0;j<=i;j++) {
			   if(a[i]==array[i])
				   count++;
		   }
		   if(count==1)
			   m.put(a[i], arr[a[i]]);
		   System.out.println();
		   }
	   return m;
	   }
   public static void main(String[] args)
   {
	   Lab7Ex2 le=new Lab7Ex2();
	   Map<Character,Integer> m1=new HashMap<Character,Integer>();
	   char a[]=new char[5];
	   Scanner sc=new Scanner(System.in);
	   for(int i=0;i<a.length;i++)
	   {
		   a[i]=sc.next().charAt(0);
	   }
	   m1=le.countCharacter(a);
	   Collection c=m1.entrySet();
	   System.out.println(c);
   }
}
