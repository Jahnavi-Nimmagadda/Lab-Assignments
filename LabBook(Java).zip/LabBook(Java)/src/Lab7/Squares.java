package Lab7;

import java.util.*;

public class Squares {
	 public static HashMap method(int[] a) {
		    HashMap<Integer, Integer> map = new HashMap<Integer, Integer>();
		 
		    for (int n: a) {
		      map.put( n, n*n);
		    }
		    return map;
		  }

	void getSquares(){
		Scanner sc=new Scanner(System.in);
		
		System.out.println("enter the size of array");
		int n=sc.nextInt();
		int[] a=new int[n];
		for(int i=0;i<a.length;i++)
		{
			System.out.println("enter a("+i+")");
			a[i]=sc.nextInt();
		}
		 HashMap<Integer, Integer> map = method(a);
		   System.out.println("square of given numbers are:");
		      System.out.println(map);
	}
	public static void main(String[] args) {
		Squares s=new Squares();
		s.getSquares();
		
		    }
	}


