package Lab7;

import java.util.*;

public class Lab7Ex1 {

	public static void main(String[] args) {
    Lab7Ex1 l=new Lab7Ex1();
    Scanner sc=new Scanner(System.in);
    HashMap<Integer,Integer> hm=new HashMap<Integer,Integer>();
    System.out.println("enter the numbers");
    for(int i=1;i<=5;i++)
    {
    	int n=sc.nextInt();
    	hm.put(i, n);
    }
    List<Integer> l1=new ArrayList<Integer>();
    l1=l.getValues(hm);
    System.out.println("sorted numbers are:");
    System.out.println(l1);
	}
	List getValues(HashMap<Integer,Integer>hm)
	{
		TreeSet<Integer> ts=new TreeSet<Integer>(hm.values());
		List<Integer> l1=new ArrayList<Integer>(ts);
		return l1;
	}

}
