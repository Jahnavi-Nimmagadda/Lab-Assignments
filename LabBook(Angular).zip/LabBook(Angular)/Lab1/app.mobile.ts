export class Mobile
{
  mobileId:number;
  mobileName:string;
  mobileCost:number;
  public constructor(mobileId:number,mobileName:string,mobileCost:number)
  {
    this.mobileId = mobileId;
    this.mobileName = mobileName;
    this.mobileCost = mobileCost;
  }
}