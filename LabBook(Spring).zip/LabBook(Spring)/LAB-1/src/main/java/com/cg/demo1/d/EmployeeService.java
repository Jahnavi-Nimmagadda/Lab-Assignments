package com.cg.demo1.d;

public interface EmployeeService {
public Employee getDetails(int empId);
}
